# Focus Stem on Netlify

Focus Stem with its own accounts. Friends sign in with Google or with an email and password. No Claude account needed.

## What's in this folder

| Path | What it is |
| --- | --- |
| `public/index.html` | The website. Same look and features as before, plus sign in. |
| `netlify/functions/api.mjs` | The backend. Handles accounts, friends, minutes, competitions and reviews. |
| `netlify.toml` | Tells Netlify where the site and the backend live. |
| `package.json` | Lists the one library the backend uses (`@netlify/blobs`). |
| `devserver.mjs` | Only for testing on your own computer. Netlify ignores it. |

Data is stored in **Netlify Blobs**, which comes with every Netlify site. There is no database to set up.

## Steps to put it online

### 1. Make the accounts
1. Make a free account at [github.com](https://github.com) if you don't have one.
2. Make a free account at [netlify.com](https://app.netlify.com/signup). Choose "Sign up with GitHub", it makes step 3 easier.

### 2. Put the files on GitHub
1. On GitHub, click **New repository**. Name it `focus-stem`. Keep it **Private**. Click **Create repository**.
2. On the new repository page, click **uploading an existing file**.
3. Drag in everything from this folder: `public`, `netlify`, `netlify.toml`, `package.json`, `README.md`, `.gitignore` (and `devserver.mjs` if you like). Folders must keep their structure: `netlify/functions/api.mjs` and `public/index.html`.
4. Click **Commit changes**.

(Or tell Claude the repository name once it exists and Claude can push the files for you.)

### 3. Connect it to Netlify
1. In Netlify, click **Add new site → Import an existing project → GitHub**, and pick `focus-stem`.
2. Leave the build settings as they are. `netlify.toml` already says publish `public` and functions `netlify/functions`.
3. Before deploying, open **Environment variables** (or after: **Site configuration → Environment variables**) and add:

| Key | Value | Why |
| --- | --- | --- |
| `SESSION_SECRET` | A long random string, at least 32 characters. | Signs everyone's sign-in. Keep it secret. Changing it signs everyone out. |
| `OWNER_INVITE` | A secret word only you know, like `GANESH-OWNER-2026` | Use it as the invite code when you make **your** account. The first account made with it becomes the owner. |
| `GOOGLE_CLIENT_ID` | From step 3b below | Turns on the **Continue with Google** button. Without it, only email sign-in shows. |
| `OPEN_SIGNUP` | `true` (optional) | Leave this out unless you want strangers to create accounts without an invite code. Anyone can still use the timer without signing in. |

4. Click **Deploy**. After a minute you get an address like `https://focus-stem-123.netlify.app`. You can rename it in **Site configuration → Change site name**.
5. If you added the variables after the first deploy, go to **Deploys → Trigger deploy → Deploy site** so they take effect.

### 3b. Turn on Continue with Google (about 10 minutes, free)
1. Go to [console.cloud.google.com](https://console.cloud.google.com) and sign in with your Google account.
2. At the top, click the project picker, then **New project**. Name it `Focus Stem` and create it.
3. Open **APIs & Services → OAuth consent screen** (it may be called **Google Auth Platform → Branding**). Click **Get started**. App name `Focus Stem`, support email yours, audience **External**, then finish.
4. Open **Audience** and click **Publish app** so anyone with a Google account can sign in (not just test users). Basic sign-in (email and name) needs no review from Google.
5. Open **Clients** (or **Credentials → Create credentials → OAuth client ID**). Type **Web application**.
6. Under **Authorized JavaScript origins**, add your site address, like `https://focus-stem-123.netlify.app`. Add your custom domain too if you use one. Leave redirect URIs empty.
7. Click **Create** and copy the **Client ID** (it ends in `.apps.googleusercontent.com`).
8. In Netlify, add it as the `GOOGLE_CLIENT_ID` environment variable, then **Deploys → Trigger deploy → Deploy site**.

If you rename your Netlify site later, update the origin in step 6 too, or the Google button will show an error.

### 4. Make your account, then invite friends
1. Open your site. Type your email and tap **Continue** (or tap **Continue with Google**). When it asks for an invite code, put in your `OWNER_INVITE` word.
2. Go to **Friends** and click **Copy**. It copies a link like `https://your-site.netlify.app/?invite=K7MPQ2`. Send it to friends. The link opens sign up with your code filled in, and they become your friend right away.
3. Each code works for up to 30 friends.

## How it works

- **Sign in**: tap Continue with Google, or type an email. A known email asks for its password; a new email makes an account. Passwords are stored hashed (scrypt), never as plain text. After 8 wrong tries an email is locked for 15 minutes. If someone used Google before, a matching email signs into the same account.
- **Forgot password**: the site doesn't send emails, so the owner resets it. Open **Settings**, and under Account type their email and a temporary password. They can change it in Settings after signing in. Google users never need a password.
- **Invite only**: a new account needs a friend's code (or your `OWNER_INVITE` word). After the owner account exists, `OWNER_INVITE` still works as a join code, but it doesn't make anyone else an owner.
- **Minutes**: saved on the device and sent to the server every 2 minutes while a focus block runs, and whenever you pause, finish or leave the tab. Minutes only go up, so two devices can't erase each other.
- **What others can see**: friends and people in your competitions see your name and minutes. Everyone signed in sees reviews. Nobody sees emails or passwords.
- **Just use the timer**: people can skip sign in. Their minutes stay on that device and are added to their account if they sign in later on it.
- **Owner powers**: remove any review, reset passwords.

## Costs

Netlify's free plan covers a group of friends. The app only calls the backend when it has something to save or when you open Friends, Progress or Reviews. Check **Usage** in the Netlify dashboard now and then if the group gets big.

## Test on your own computer (optional)

Needs [Node.js](https://nodejs.org) 20 or newer.

```
npm install
node devserver.mjs
```

Then open http://localhost:8888. The local owner invite word is `BOSS-KEY`. The Google button needs `GOOGLE_CLIENT_ID` set and `http://localhost:8888` added as an origin in Google Cloud.
