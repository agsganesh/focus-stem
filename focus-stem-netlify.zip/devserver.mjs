// Local test server only: a Netlify Blobs emulator, the static site and the /api function.
// Run: node devserver.mjs <data-folder>   then open http://localhost:8888
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { BlobsServer } from "@netlify/blobs/server";

const dir = process.argv[2] || ".blobs-local";
const blobs = new BlobsServer({ directory: dir, token: "local", port: 8971 });
await blobs.start();
process.env.NETLIFY_BLOBS_CONTEXT = Buffer.from(JSON.stringify({ edgeURL: "http://localhost:8971", uncachedEdgeURL: "http://localhost:8971", siteID: "local", token: "local" })).toString("base64");
process.env.SESSION_SECRET ||= "local-test-secret-1234567890";
process.env.OWNER_INVITE ||= "BOSS-KEY";
const { default: handler } = await import("./netlify/functions/api.mjs");

http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost:8888");
  if (url.pathname.startsWith("/api/")) {
    const chunks = []; for await (const c of req) chunks.push(c);
    const r = await handler(new Request(url, { method: req.method, headers: req.headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : Buffer.concat(chunks) }));
    res.writeHead(r.status, Object.fromEntries(r.headers)); res.end(Buffer.from(await r.arrayBuffer()));
    return;
  }
  const f = path.join("public", url.pathname === "/" ? "index.html" : url.pathname);
  if (!f.startsWith("public") || !fs.existsSync(f)) { res.writeHead(404); res.end(); return; }
  res.writeHead(200, { "content-type": "text/html" }); res.end(fs.readFileSync(f));
}).listen(8888, () => console.log("ready on http://localhost:8888"));
