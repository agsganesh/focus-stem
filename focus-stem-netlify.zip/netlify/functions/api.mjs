// Focus Stem backend: accounts, friends, focus totals, competitions and reviews.
// One function answers every /api/* route. Data lives in a Netlify Blobs store named "stem".
//
// Keys in the store:
//   user/<email>           account: id, password hash (if any), Google id (if any), owner flag
//   google/<sub>           Google account id -> email
//   player/<id>            focus record: name, code, days, blocks, ms
//   code/<CODE>            invite code -> player id
//   edge/<a>/<b>           a and b are friends (written both ways)
//   comp/<creatorId>       that person's competition, plus finished ones in history
//   cm/<memberId>/<creatorId>  index: member is in creator's competition
//   review/<id>            one review per person
//   fail/<email>           failed sign-in counter
//   meta/owner             who the site owner is

import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/*" };

const MAX_FRIENDS = 30;
const CODE_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
const TOKEN_DAYS = 180;
const MILESTONES = [1, 25, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000];
const DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
const ID_RE = /^[0-9a-f-]{36}$/;

const store = () => getStore({ name: "stem", consistency: "strong" });
const env = k => (globalThis.Netlify ? Netlify.env.get(k) : process.env[k]) || "";

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (status, msg) => { throw new HttpError(status, msg); };
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

// ---------- Auth ----------
const b64u = buf => Buffer.from(buf).toString("base64url");
function secret() {
  const s = env("SESSION_SECRET");
  if (s.length < 16) fail(500, "The site isn't set up yet: SESSION_SECRET is missing.");
  return s;
}
const sign = body => b64u(crypto.createHmac("sha256", secret()).update(body).digest());
function makeToken(user) {
  const body = b64u(JSON.stringify({ u: user.uname, v: user.tv || 0, e: Date.now() + TOKEN_DAYS * 864e5 }));
  return body + "." + sign(body);
}
async function authed(req, db) {
  const h = req.headers.get("authorization") || "";
  const [body, mac] = h.replace(/^Bearer\s+/i, "").split(".");
  if (!body || !mac) fail(401, "Please sign in.");
  const want = Buffer.from(sign(body)), got = Buffer.from(mac);
  if (want.length !== got.length || !crypto.timingSafeEqual(want, got)) fail(401, "Please sign in again.");
  let t; try { t = JSON.parse(Buffer.from(body, "base64url").toString()); } catch (e) { fail(401, "Please sign in again."); }
  if (!t.e || t.e < Date.now()) fail(401, "Your sign-in expired. Please sign in again.");
  const user = await db.get("user/" + t.u, { type: "json" });
  if (!user || (user.tv || 0) !== t.v) fail(401, "Please sign in again.");
  return user;
}
function hashPw(pw, salt) {
  return new Promise((res, rej) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => e ? rej(e) : res(k.toString("hex"))));
}
async function checkPw(user, pw) {
  const h = await hashPw(pw, user.salt);
  return crypto.timingSafeEqual(Buffer.from(h, "hex"), Buffer.from(user.hash, "hex"));
}
const cleanName = s => String(s || "").replace(/\s+/g, " ").trim().slice(0, 24);
const cleanUser = s => String(s || "").trim().toLowerCase();
const EMAIL_RE = /^[^\s@/]{1,64}@[^\s@/]{1,190}\.[a-z]{2,}$/;
function checkNewPassword(pw) {
  if (typeof pw !== "string" || pw.length < 8) fail(400, "Passwords need at least 8 characters.");
  if (pw.length > 200) fail(400, "That password is too long.");
}

// ---------- Records ----------
async function newCode(db, id) {
  for (let i = 0; i < 20; i++) {
    const code = Array.from(crypto.randomBytes(6), b => CODE_CHARS[b % CODE_CHARS.length]).join("");
    const r = await db.setJSON("code/" + code, { id }, { onlyIfNew: true });
    if (r.modified) return code;
  }
  fail(500, "Couldn't make an invite code. Try again.");
}
async function friendIds(db, id) {
  const { blobs } = await db.list({ prefix: "edge/" + id + "/" });
  return blobs.map(b => b.key.split("/")[2]);
}
const getJSON = (db, key) => db.get(key, { type: "json" });
const secBetween = (p, a, b) => Object.entries(p.days || {}).reduce((s, [k, v]) => k >= a && k <= b ? s + v : s, 0);
const dayKey = ts => new Date(ts).toISOString().slice(0, 10);
function winnersOf(c, players) {
  // Day keys are the creator's local dates, sent when the competition started.
  const a = c.startKey || dayKey(c.startAt), b = c.endKey || dayKey(c.endAt - 1);
  const s = (c.members || []).filter(id => players[id]).map(id => ({ id, sec: secBetween(players[id], a, b) })).sort((x, y) => y.sec - x.sec);
  if (!s.length || s[0].sec < 60) return [];
  return s.filter(x => x.sec === s[0].sec).map(x => x.id);
}

// Read-modify-write a JSON blob, retrying if someone else wrote it in between.
async function update(db, key, fn) {
  for (let i = 0; i < 6; i++) {
    const cur = await db.getWithMetadata(key, { type: "json" });
    const next = fn(cur ? cur.data : null);
    const r = cur ? await db.setJSON(key, next, { onlyIfMatch: cur.etag }) : await db.setJSON(key, next, { onlyIfNew: true });
    if (r.modified) return next;
  }
  fail(409, "Busy right now. Try again.");
}

// Everything the signed-in person needs to draw the app.
async function stateFor(db, user) {
  const id = user.id;
  const [me, fids, cmList] = await Promise.all([getJSON(db, "player/" + id), friendIds(db, id), db.list({ prefix: "cm/" + id + "/" })]);
  const creators = [...new Set([id, ...cmList.blobs.map(b => b.key.split("/")[2])])];
  const compDocs = await Promise.all(creators.map(c => getJSON(db, "comp/" + c)));
  const comps = {};
  creators.forEach((c, i) => {
    const d = compDocs[i]; if (!d) return;
    const inNow = (d.members || []).includes(id);
    const history = (d.history || []).filter(h => (h.members || []).includes(id));
    if (inNow || history.length) comps[c] = inNow ? Object.assign({}, d, { history }) : { history };
  });
  const need = new Set(fids);
  for (const c of Object.values(comps)) { (c.members || []).forEach(m => need.add(m)); (c.history || []).forEach(h => (h.members || []).forEach(m => need.add(m))); }
  need.delete(id);
  const ids = [...need];
  const docs = await Promise.all(ids.map(o => getJSON(db, "player/" + o)));
  const players = { [id]: me };
  ids.forEach((o, i) => { const p = docs[i]; if (p) players[o] = { name: p.name, days: p.days || {}, blocks: p.blocks || {} }; });
  return { me: { id, username: user.uname, google: !!user.google, hasPassword: !!user.hash, isOwner: !!user.owner }, player: me, friends: fids.filter(f => players[f]), players, comps };
}

// ---------- Routes ----------
// Who may join: a friend's code, the owner word, or anyone when OPEN_SIGNUP is on.
async function checkInvite(db, raw) {
  const invite = String(raw || "").trim().toUpperCase();
  const ownerInvite = env("OWNER_INVITE").trim().toUpperCase();
  if (ownerInvite && invite === ownerInvite) return { owner: true };
  if (/^[A-Z0-9]{6}$/.test(invite)) {
    const hit = await getJSON(db, "code/" + invite);
    if (!hit) fail(400, "That invite code doesn't match anyone. Check it with your friend.");
    if ((await friendIds(db, hit.id)).length >= MAX_FRIENDS) fail(400, "Your friend already has 30 friends, so their code is full.");
    return { inviter: hit.id };
  }
  if (env("OPEN_SIGNUP") === "true") return {};
  fail(400, invite ? "That invite code doesn't look right. Codes are 6 letters and numbers." : "You need an invite code from a friend to join.");
}

async function createAccount(db, email, fields, inviteRaw, name) {
  const { owner, inviter } = await checkInvite(db, inviteRaw);
  const id = crypto.randomUUID();
  const user = Object.assign({ id, uname: email, owner: !!owner, tv: 0, createdAt: Date.now() }, fields);
  const r = await db.setJSON("user/" + email, user, { onlyIfNew: true });
  if (!r.modified) fail(409, "There's already an account with that email. Sign in instead.");
  // Only the first person to use OWNER_INVITE becomes the owner. After that it works as a plain join code.
  if (owner) { const o = await db.setJSON("meta/owner", { id, uname: email }, { onlyIfNew: true }); if (!o.modified) { user.owner = false; await db.setJSON("user/" + email, user); } }
  const code = await newCode(db, id);
  await db.setJSON("player/" + id, { name: cleanName(name) || email.split("@")[0].slice(0, 24), code, days: {}, blocks: {}, ms: {}, createdAt: Date.now(), updatedAt: Date.now() });
  if (inviter) await Promise.all([db.setJSON("edge/" + id + "/" + inviter, { at: Date.now() }), db.setJSON("edge/" + inviter + "/" + id, { at: Date.now() })]);
  return user;
}

// Step one of the email form: does this email have an account, and how does it sign in?
async function checkEmail(db, body) {
  const email = cleanUser(body.email);
  if (!EMAIL_RE.test(email)) fail(400, "Enter a valid email address.");
  const user = await getJSON(db, "user/" + email);
  return { exists: !!user, password: !!(user && user.hash), google: !!(user && user.google) };
}

async function signup(db, body) {
  const email = cleanUser(body.email);
  if (!EMAIL_RE.test(email)) fail(400, "Enter a valid email address.");
  checkNewPassword(body.password);
  const salt = b64u(crypto.randomBytes(16));
  const user = await createAccount(db, email, { salt, hash: await hashPw(body.password, salt) }, body.invite, body.name);
  return { token: makeToken(user), state: await stateFor(db, user) };
}

// ---------- Google ----------
let googleKeys = null, googleKeysAt = 0;
async function googleKey(kid) {
  if (!googleKeys || Date.now() - googleKeysAt > 3600e3 || !googleKeys.find(k => k.kid === kid)) {
    const r = await fetch("https://www.googleapis.com/oauth2/v3/certs");
    if (!r.ok) fail(502, "Couldn't reach Google. Try again.");
    googleKeys = (await r.json()).keys || []; googleKeysAt = Date.now();
  }
  const jwk = googleKeys.find(k => k.kid === kid);
  if (!jwk) fail(401, "Google sign-in didn't check out. Try again.");
  return crypto.createPublicKey({ key: jwk, format: "jwk" });
}
async function verifyGoogle(credential) {
  const clientId = env("GOOGLE_CLIENT_ID");
  if (!clientId) fail(400, "Google sign-in isn't set up on this site yet.");
  const parts = String(credential || "").split(".");
  if (parts.length !== 3) fail(400, "Google sign-in didn't check out. Try again.");
  let head, claims;
  try { head = JSON.parse(Buffer.from(parts[0], "base64url")); claims = JSON.parse(Buffer.from(parts[1], "base64url")); } catch (e) { fail(400, "Google sign-in didn't check out. Try again."); }
  if (head.alg !== "RS256") fail(400, "Google sign-in didn't check out. Try again.");
  const ok = crypto.verify("RSA-SHA256", Buffer.from(parts[0] + "." + parts[1]), await googleKey(head.kid), Buffer.from(parts[2], "base64url"));
  if (!ok || claims.aud !== clientId || !["accounts.google.com", "https://accounts.google.com"].includes(claims.iss) || claims.exp * 1000 < Date.now()) fail(401, "Google sign-in didn't check out. Try again.");
  if (!claims.email || claims.email_verified === false) fail(400, "Your Google account needs a verified email.");
  return claims;
}
async function google(db, body) {
  const g = await verifyGoogle(body.credential);
  const email = cleanUser(g.email);
  const link = await getJSON(db, "google/" + g.sub);
  let user = await getJSON(db, "user/" + (link ? link.email : email));
  if (user && !user.google) { user = Object.assign({}, user, { google: g.sub }); await db.setJSON("user/" + user.uname, user); }
  if (!user) {
    // New here: the page asks for an invite code, then sends the same Google sign-in again with it.
    if (!body.invite && env("OPEN_SIGNUP") !== "true") return { needInvite: true, email, name: cleanName(g.given_name || g.name) };
    user = await createAccount(db, email, { google: g.sub }, body.invite, body.name || g.given_name || g.name);
  }
  await db.setJSON("google/" + g.sub, { email: user.uname });
  return { token: makeToken(user), state: await stateFor(db, user) };
}

async function login(db, body) {
  const uname = cleanUser(body.email);
  if (!uname) fail(400, "Enter your email.");
  const f = await getJSON(db, "fail/" + uname);
  if (f && f.n >= 8 && Date.now() - f.at < 15 * 60e3) fail(429, "Too many tries. Wait 15 minutes and try again.");
  const user = uname && await getJSON(db, "user/" + uname);
  if (user && !user.hash) fail(400, "This account uses Google. Tap Continue with Google.");
  if (!user || !(await checkPw(user, String(body.password || "")))) {
    await db.setJSON("fail/" + uname, { n: (f && Date.now() - f.at < 15 * 60e3 ? f.n : 0) + 1, at: Date.now() });
    fail(401, "That email and password don't match.");
  }
  if (f) await db.delete("fail/" + uname);
  return { token: makeToken(user), state: await stateFor(db, user) };
}

// Merge the client's focus record into the stored one. Minutes only ever go up, so two devices can't erase each other.
async function saveMe(db, user, body) {
  await update(db, "player/" + user.id, cur => {
    const p = cur || { days: {}, blocks: {}, ms: {} };
    p.days = p.days || {}; p.blocks = p.blocks || {}; p.ms = p.ms || {};
    for (const [k, v] of Object.entries(body.days || {}).slice(-4000)) {
      if (DAY_RE.test(k) && Number.isFinite(v)) p.days[k] = Math.max(p.days[k] || 0, Math.min(86400, Math.max(0, Math.round(v))));
    }
    for (const [k, v] of Object.entries(body.blocks || {}).slice(-4000)) {
      if (DAY_RE.test(k) && Number.isFinite(v)) p.blocks[k] = Math.max(p.blocks[k] || 0, Math.min(500, Math.max(0, Math.round(v))));
    }
    for (const [k, v] of Object.entries(body.ms || {})) {
      if (MILESTONES.includes(+k) && Number.isFinite(v) && v > 0 && (!p.ms[k] || v < p.ms[k])) p.ms[k] = v;
    }
    if (typeof body.name === "string" && cleanName(body.name)) p.name = cleanName(body.name);
    p.updatedAt = Date.now();
    return p;
  });
  return stateFor(db, user);
}

async function addFriend(db, user, body) {
  const code = String(body.code || "").trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) fail(400, "Codes are 6 letters and numbers, like K7MPQ2.");
  const hit = await getJSON(db, "code/" + code);
  if (!hit) fail(404, "No one has that code. Check it with your friend.");
  if (hit.id === user.id) fail(400, "That's your own code. Share it with a friend instead.");
  const [mine, theirs] = await Promise.all([friendIds(db, user.id), friendIds(db, hit.id)]);
  if (mine.includes(hit.id)) fail(400, "You're already friends.");
  if (mine.length >= MAX_FRIENDS) fail(400, "You already have 30 friends, the most allowed.");
  if (theirs.length >= MAX_FRIENDS) fail(400, "Your friend already has 30 friends.");
  await Promise.all([db.setJSON("edge/" + user.id + "/" + hit.id, { at: Date.now() }), db.setJSON("edge/" + hit.id + "/" + user.id, { at: Date.now() })]);
  const p = await getJSON(db, "player/" + hit.id);
  return { added: (p && p.name) || "your friend", state: await stateFor(db, user) };
}

async function removeFriend(db, user, fid) {
  await Promise.all([db.delete("edge/" + user.id + "/" + fid), db.delete("edge/" + fid + "/" + user.id)]);
  return stateFor(db, user);
}

async function startComp(db, user, body) {
  const days = [3, 7, 14, 30].includes(+body.days) ? +body.days : 7;
  const friends = await friendIds(db, user.id);
  if (!friends.length) fail(400, "Add at least one friend first.");
  const startAt = Number.isFinite(body.startAt) && Math.abs(body.startAt - Date.now()) < 864e5 ? body.startAt : Date.now();
  const members = [user.id, ...friends];
  const cur = await getJSON(db, "comp/" + user.id);
  if (cur && cur.endAt > Date.now()) fail(400, "You already have a competition running.");
  const history = cur ? (cur.history || []).slice(-20) : [];
  if (cur && cur.endAt) {
    const docs = await Promise.all((cur.members || []).map(m => getJSON(db, "player/" + m)));
    const players = {}; (cur.members || []).forEach((m, i) => { if (docs[i]) players[m] = docs[i]; });
    history.push({ name: cur.name, days: cur.days, startAt: cur.startAt, endAt: cur.endAt, startKey: cur.startKey, endKey: cur.endKey, members: cur.members, winners: winnersOf(cur, players) });
  }
  const rec = { name: String(body.name || "").trim().slice(0, 40) || days + "-day challenge", days, startAt, endAt: startAt + days * 864e5, members, history, createdAt: Date.now() };
  if (DAY_RE.test(body.startKey) && DAY_RE.test(body.endKey)) { rec.startKey = body.startKey; rec.endKey = body.endKey; }
  await db.setJSON("comp/" + user.id, rec);
  await Promise.all(members.map(m => db.setJSON("cm/" + m + "/" + user.id, { at: Date.now() })));
  return { count: friends.length, state: await stateFor(db, user) };
}

async function endComp(db, user) {
  await update(db, "comp/" + user.id, cur => {
    if (!cur) fail(404, "No competition to end.");
    return Object.assign({}, cur, { endAt: Math.min(cur.endAt, Date.now()) });
  });
  return stateFor(db, user);
}

async function listReviews(db) {
  const { blobs } = await db.list({ prefix: "review/" });
  const docs = await Promise.all(blobs.map(b => getJSON(db, b.key)));
  const out = {};
  blobs.forEach((b, i) => { if (docs[i]) out[b.key.slice(7)] = docs[i]; });
  return { reviews: out };
}
async function saveReview(db, user, body) {
  const stars = Math.round(+body.stars);
  if (!(stars >= 1 && stars <= 5)) fail(400, "Pick a star rating first.");
  const me = await getJSON(db, "player/" + user.id);
  await update(db, "review/" + user.id, prev => ({
    stars, text: String(body.text || "").trim().slice(0, 800), name: (me && me.name) || user.uname,
    createdAt: (prev && prev.createdAt) || Date.now(), updatedAt: Date.now()
  }));
  return listReviews(db);
}
async function deleteReview(db, user, id) {
  if (id !== user.id && !user.owner) fail(403, "You can only remove your own review.");
  await db.delete("review/" + id);
  return listReviews(db);
}

async function changePassword(db, user, body) {
  if (user.hash && !(await checkPw(user, String(body.current || "")))) fail(400, "Your current password isn't right.");
  checkNewPassword(body.password);
  const salt = b64u(crypto.randomBytes(16));
  const next = Object.assign({}, user, { salt, hash: await hashPw(body.password, salt), tv: (user.tv || 0) + 1 });
  await db.setJSON("user/" + user.uname, next);
  return { token: makeToken(next) };
}
// The owner can set a temporary password for someone who forgot theirs.
async function resetPassword(db, user, body) {
  if (!user.owner) fail(403, "Only the site owner can reset passwords.");
  const uname = cleanUser(body.email);
  const target = await getJSON(db, "user/" + uname);
  if (!target) fail(404, "No account has that email.");
  checkNewPassword(body.password);
  const salt = b64u(crypto.randomBytes(16));
  await db.setJSON("user/" + uname, Object.assign({}, target, { salt, hash: await hashPw(body.password, salt), tv: (target.tv || 0) + 1 }));
  await db.delete("fail/" + uname);
  return { ok: true };
}

export default async (req) => {
  const db = store();
  const path = new URL(req.url).pathname.replace(/^\/api\/?/, "").replace(/\/$/, "");
  const m = req.method;
  try {
    const text = m === "GET" || m === "DELETE" ? "" : await req.text();
    let body = {};
    if (text) { try { body = JSON.parse(text) || {}; } catch (e) { fail(400, "Bad request."); } }
    if (m === "POST" && path === "signup") return json(await signup(db, body));
    if (m === "POST" && path === "login") return json(await login(db, body));
    if (m === "POST" && path === "check") return json(await checkEmail(db, body));
    if (m === "POST" && path === "google") return json(await google(db, body));
    if (m === "GET" && path === "config") return json({ googleClientId: env("GOOGLE_CLIENT_ID") || null });
    const user = await authed(req, db);
    const tail = path.split("/")[1];
    if (tail !== undefined && !ID_RE.test(tail) && !["end"].includes(tail)) return json({ error: "Not found." }, 404);
    if (m === "GET" && path === "state") return json(await stateFor(db, user));
    if (m === "PUT" && path === "me") return json(await saveMe(db, user, body));
    if (m === "POST" && path === "friends") return json(await addFriend(db, user, body));
    if (m === "DELETE" && path.startsWith("friends/")) return json(await removeFriend(db, user, path.slice(8)));
    if (m === "POST" && path === "comps") return json(await startComp(db, user, body));
    if (m === "POST" && path === "comps/end") return json(await endComp(db, user));
    if (m === "GET" && path === "reviews") return json(await listReviews(db));
    if (m === "PUT" && path === "reviews") return json(await saveReview(db, user, body));
    if (m === "DELETE" && path.startsWith("reviews/")) return json(await deleteReview(db, user, path.slice(8)));
    if (m === "POST" && path === "password") return json(await changePassword(db, user, body));
    if (m === "POST" && path === "reset-password") return json(await resetPassword(db, user, body));
    return json({ error: "Not found." }, 404);
  } catch (e) {
    if (e instanceof HttpError) return json({ error: e.message }, e.status);
    console.error(e);
    return json({ error: "Something went wrong on the server. Try again." }, 500);
  }
};
